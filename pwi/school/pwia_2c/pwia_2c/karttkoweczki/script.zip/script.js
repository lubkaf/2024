var haslo = prompt('Podaj hasło');
var wzor = /[0-9]{1} [a-z]{3} [!@#$%^&*()_+-=/?'";:][{}]{1} \s{1}  [a-z]{3} .y /g;

var czyDobrze = haslo.match(wzor);



if(!czyDobrze)
{
    alert('zle haslo');
}




function dodaj_element_listy()
{
    let element = document.createElement("li");
    let lista = document.getElementById('lista');
    let dane = document.getElementById('dane');

    element.innerText = dane.value;
    if(element.innerText != '')
    {
        lista.appendChild(element);
    }
}